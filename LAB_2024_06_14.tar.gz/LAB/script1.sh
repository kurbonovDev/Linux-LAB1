#!/bin/bash

echo Welocome boss, $(whoami)
